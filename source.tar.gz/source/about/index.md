---
title: Ptbsare
author: Ptbsare
comments: false
date: 2014-6-24 15:05:05+00:00
---
##学生一枚

###爱好:

**互联网 开源 Github TED Linux Yanni音乐 Design 当代小说 Minecraft 智能硬件 Mac**

###社交网站:
<!--**VJianKe:**　[http://www.vjianke.com/digest/e5de3f6524f24209979051e23d109731.clip]
**RenRen:**　 [http://www.renren.com/467369931]-->
**Sina:**　　  [http://weibo.com/2168291303]
<!--**Qzone:**　  [http://user.qzone.qq.com/496725701]-->

###友情链接
[Blanboom](http://blanboom.org)　　　[Skybabi](http://skybabi.github.io)
