title: '《Viva La Vida》-生命万岁'
date: 2014-09-21 11:40:47
tags: [Music]
toc: false
---

##简介
　　Coldplay是英国摇滚乐坛进入新世纪之后崛起的最受欢迎的摇滚乐队之一。他们秉承了英式摇滚乐队一贯的Britpop/Alternative Rock英伦风格，成为了英国新一代乐队中的杰出代表。Coldplay有四个成员，乐队最早成形于伦敦大学学院 (UCL)时期。团员包括Chris Martin（主唱、键盘、吉他）、jon buckland（主奏吉他）、Guy Berryman（贝斯吉他）及Will Champion（鼓、合音、其他乐器）。

![](/img/《viva-la-vida》-生命万岁/viva3.jpg)

##歌曲简介
　　本篇要介绍的曲目Viva La Vida出自其2008年发行的专辑《Viva La Vida》(又名《Death And All His Friends》)。viva la vida是西班牙语，意思是Long live life生命万岁，中文译为生命万岁。
![](/img/《viva-la-vida》-生命万岁/viva1.jpg)
<div>
<audio src="/img/《viva-la-vida》-生命万岁/b.mp3" controls="controls" preload="auto" /></div>
* 该专辑的专辑封面是《自由引导人民》，由法国画家欧仁·德拉克罗瓦（Eugène Delacroix）为纪念1830年法国七月革命而创作的油画作品。本画取材于1830年法国的七月革命事件。1830年7月26日，国王查理十世取消议会，巴黎市民纷纷起义。27至29日为推翻波旁王朝，与保皇党展开了战斗，并占领了王宫，在历史上称为"光荣的三天"。在这次战斗中，一位名叫克拉拉·莱辛的姑娘首先在街垒上举起了象征法兰西共和制的三色旗；少年阿莱尔把这面旗帜插到巴黎圣母院旁的一座桥头时，中弹倒下。画家德拉克洛瓦目击了这一悲壮激烈的景象，又义愤填膺，决心为之画一幅画作为永久的纪念
* 本歌曲歌词讲述的是法国资产阶级革命爆发后，路易十六与王后玛丽•安东尼特以里通外国的反革命罪和阴谋复辟罪被处以死刑。该歌曲的歌词翻译有多个版本。
* 对于本歌曲，如果不对历史和时态多加分析，歌词的翻译也只能留于表面，经不起推敲。


**下面是歌词翻译大赛一等奖获得者Chaosphinx的翻译作品：**


    Viva La Vida
    生命万岁  
    
    I used to rule the world  
    Seas would rise when I gave the word  
    Now in the morning I sleep alone  
    Sweep the streets I used to own  
    大千世界曾由我主宰  
    巨浪也曾因我之命澎湃  
    而今我却在黎明独自入眠  
    在曾属于我的大道落寞徘徊  
    
    I used to roll the dice  
    Feel the fear in my enemy's eyes  
    Listen as the crowd would sing:  
    "Now the old king is dead! Long live the king!"  
    凡人生死曾由我主宰  
    尽情品味惊恐在死敌瞳孔绽开  
    欣然倾听百姓高歌喝彩：  
    “先王亡矣！新王万代！”  
    
    One minute I held the key  
    Next the walls were closed on me  
    And I discovered that my castles stand  
    Upon pillars of salt and pillars of sand  
    此刻我手握权位经脉  
    转瞬才知宫墙深似海  
    恍然发现我的城池  
    基底散如盐沙乱似尘埃  
    
    I hear Jerusalem bells a ringing  
    Roman Cavalry choirs are singing  
    Be my mirror my sword and shield  
    My missionaries in a foreign field  
    听那耶路撒冷钟声传来  
    罗马骑兵歌声震彻山海  
    担当我的明镜，利剑和盾牌  
    我的传教士屹立边疆之外  
    
    For some reason I can't explain  
    Once you go there was never,  
    never an honest word  
    That was when I ruled the world  
    只因一些缘由我无法释怀  
    一旦你离开这里便不再，  
    不再有逆耳忠言存在  
    而这便是我统治的时代  
    
    It was the wicked and wild wind  
    Blew down the doors to let me in  
    Shattered windows and the sound of drums  
    People couldn't believe what I'd become  
    凛冽邪风呼啸袭来  
    吹散重门使我深陷阴霾  
    断壁残垣礼崩乐坏  
    世人不敢相信我已当年不再  
    
    Revolutionaries wait  
    For my head on a silver plate  
    Just a puppet on a lonely string  
    Oh who would ever want to be king?  
    起义大军翘首期待  
    有朝一日我站上断头台  
    恰如傀儡随吊线寂寞摇摆  
    悲哉，谁又曾渴望万人膜拜？  
    
    I hear Jerusalem bells a ringing  
    Roman Cavalry choirs are singing  
    Be my mirror my sword and shield  
    My missionaries in a foreign field  
    听那耶路撒冷钟声传来  
    罗马骑兵歌声震彻山海  
    担当我的明镜，利剑和盾牌  
    我的传教士屹立边疆之外  
    
    For some reason I can't explain  
    I know Saint Peter won't call my name  
    Never an honest word  
    But that was when I ruled the world  
    只因一些缘由我无法释怀  
    我亦知天堂之门不会为我敞开  
    不再有逆耳忠言存在  
    但这却是我统治的时代
    
    (Oh...Oh...Oh...)
    
    I hear Jerusalem bells a ringing  
    Roman Cavalry choirs are singing  
    Be my mirror my sword and shield  
    My missionaries in a foreign field  
    听那耶路撒冷钟声传来  
    罗马骑兵歌声震彻山海  
    担当我的明镜，利剑和盾牌  
    我的传教士屹立边疆之外  
    
    For some reason I can't explain  
    I know Saint Peter won't call my name  
    Never an honest word  
    But that was when I ruled the world  
    只因一些缘由我无法释怀  
    我亦知天堂之门不会为我敞开  
    不再有逆耳忠言存在  
    但这却是我统治的时代
		　　　

##作者翻译心得

　　《Viva La Vida》歌词如同旋律一般，铿锵有力，激情四射，但歌词的翻译过程却步履维艰。语句中随处可见的一些欧洲中世纪历史信息以及与基督教相关词语给翻译过程带来了很多困难，部分语句含义比较隐晦，只得在查阅一些资料后，才慢慢开始着手翻译工作。  
　　在最终大功告成后，回头再看，不由赞叹Coldplay作品的磅礴与大气：一国之君人前的无上荣耀与背后的落寞孤独，以及当权位摇摇欲倾时的哀叹，Oh who would ever want to be king，都使自己久久陷入沉思。歌词所影射的国王（根据资料可能为路易十六），以及中国历史中的李后主、明熹宗，在某些方面令世人赞叹，但却只落得“昏君”二字，念及此，谁又会愿意为王呢。  
　　王侯将相，不过凡人；生命不息，闪耀出生命最绚烂的色彩，足以不朽。  
　　Viva La Vida，生命万岁。

##MV
<video controls="controls" preload="auto" src="/img/《viva-la-vida》-生命万岁/a.mp4" ></video>

##后记
* 后经查阅资料得知Coldplay的主唱（包括键盘，吉他）Chris Martin 曾取得的学位是伦敦大学学院古代文字研究的第一级学位;其能创作出如此磅礴的作品也就不难理解。
* 中国古代也有类似的诗句：
**春花秋月何时了？往事知多少！小楼昨夜又东风，故国不堪回首月明中。**
**雕阑玉砌应犹在，只是朱颜改。问君能有几多愁？恰似一江春水向东流。　　　--李煜《虞美人》**

* 历史本是相通的。其实中国也有辉煌灿烂的文化，只是现代人没有沉下心境去读懂这些诗句罢了。
* 在写这篇时一直有两句话在我脑海里萦绕：“有两种办法可以让文化精神枯竭，一种，让文化成为一个监狱，另一种是，让文化成为一场滑稽戏。”反观中国当代以娱乐至上的互联网文化，似乎正在逐渐将中国的文化变成一场滑稽戏。
* 写此篇博文几天后有感而发，遂记录更新于此后记。
（完）

**参考**
(http://www.douban.com/note/155092893/)
