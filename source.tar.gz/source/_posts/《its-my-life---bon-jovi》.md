title: '《It''s My Life - Bon Jovi》'
date: 2014-08-08 14:10:39
tags: [Music]
---

Bon Jovi-是当代美国摇滚乐队，少年时期即开始接触摇滚乐。1983年组建同名乐队，逐渐占据市场。以主流硬摇滚、金属摇滚见长。
![](/img/《its-my-life---bon-jovi》/bonjovi.jpg)
It's My Life 出自其2000年的专辑《Crush》，这部专辑被誉为让新一代美国人重新燃起象他们的长辈一样热爱摇滚的火炬之作。
![](/img/《its-my-life---bon-jovi》/itismylife.jpg)
这首歌曲有两个版本，分别为慢节奏版和快节奏版。

<div>慢节奏版:
<audio controls="controls" src="/img/《its-my-life---bon-jovi》/manban.mp3" /></div>

歌词及翻译：

    歌名：It's my life
    歌手：Bon Jovi
    专辑：<Crush>
    It's My Life 
    
    This ain't a song for the broken-hearted 
    这不是一首给伤心人的歌 
    No silent prayer for the faith-departed 
    没有为失去信仰者的默祷 
    I ain't gonna be just a face in the crowd 
    我不希望自己只是芸芸众生之一 
    You're gonna hear my voice 
    你将会听到我的声音 
    When I shout it out loud 
    当我大声呐喊出来 
    
    
    It's my life 
    这是我的人生 
    It's now or never 
    把握现在，机会稍纵即逝 
    I ain't gonna live forever 
    我不希望长生不死 
    I just want to live while I'm alive 
    我只想趁活著得时候认真的生活 
    (It's my life) 
    （这是我的人生） 
    My heart is like an open highway 
    我的心像是开放的高速公路 
    Like Frankie said 
    就像法兰克辛那屈唱的： 
    I did it my way 
    我走自己的路 
    I just wanna live while I'm alive 
    我只想趁活著的时候认真的生活 
    It's my life 
    这是我的人生 
    
    This is for the ones who stood their ground 
    这是为坚守信念的人们而唱 
    For Tommy and Gina who never backed down 
    为从不退缩的汤米和吉娜而唱 
    Tomorrow's getting harder make no mistake 
    毫无疑问的，未来日趋艰辛 
    Luck ain't even lucky 
    幸运不再幸运 
    Got to make your own breaks 
    你必须自己寻求突破 
    
    
    It's my life 
    这是我的人生 
    It's now or never 
    把握现在，机会稍纵即逝 
    I ain't gonna live forever 
    我不希望长生不死 
    I just want to live while I'm alive 
    我只想趁活著得时候认真的生活 
    (It's my life) 
    （这是我的人生） 
    My heart is like an open highway 
    我的心像是开放的高速公路 
    Like Frankie said 
    就像法兰克辛那屈唱的： 
    I did it my way 
    我走自己的路 
    I just wanna live while I'm alive 
    我只想趁活著的时候认真的生活 
    'Cause it's my life 
    这是我的人生 
    
    Better stand tall when they're calling you out 
    当别人找你麻烦，挺直身子 
    Don't bend, don't break, baby, don't back down 
    不要屈服，不要放弃，宝贝，不要畏缩 
    
    
    It's my life 
    这是我的人生 
    It's now or never 
    把握现在，机会稍纵即逝 
    I ain't gonna live forever 
    我不希望长生不死 
    I just want to live while I'm alive 
    我只想趁活著得时候认真的生活 
    (It's my life) 
    （这是我的人生） 
    My heart is like an open highway 
    我的心像是开放的高速公路 
    Like Frankie said 
    就像法兰克辛那屈唱的： 
    I did it my way 
    我走自己的路 
    I just wanna live while I'm alive 
    我只想趁活著的时候认真的生活 
    
    
    It's my life 
    这是我的人生 
    It's now or never 
    把握现在，机会稍纵即逝 
    I ain't gonna live forever 
    我不希望长生不死 
    I just want to live while I'm alive 
    我只想趁活著得时候认真的生活 
    (It's my life) 
    （这是我的人生）

<div>
摇滚版本:
<audio controls="controls" src="/img/《its-my-life---bon-jovi》/yaogunban.mp3" />
</div>
![](/img/《its-my-life---bon-jovi》/itismylife3.jpg)
<div>
MV:
<video controls="controls" src="/img/《its-my-life---bon-jovi》/4.mp4" />
</div>

参考：
(http://baike.baidu.com/link?url=_eHe_hM-M71_d4EQqMpQtUINhpWq0v04qDpczMXldDzG8uJweYIj2YSZRkLsnLSSGHbAbqOyMZP83Ab6ql5Bl_)
注：本页音频和视频均采用html5技术呈现。
